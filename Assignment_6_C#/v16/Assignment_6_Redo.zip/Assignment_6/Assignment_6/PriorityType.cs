﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment_6
{
    public enum PriorityType
    {
        Very_important,
        Important,
        Normal,
        Less_important,
        Not_important
    }
}
